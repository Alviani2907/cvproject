<?php

namespace App\Controllers;

use App\Models\cvmodel;

class Home extends BaseController
{
    protected $cvproject;
    public function __construct()
    {
        $this->cvproject = new cvmodel;
    }

    public function index(): string
    {

        // About
        $abouts = new cvmodel();
        $about = $abouts->About();

        // Counts
        // $counts = new Home();
        // $count = $counts->Counts();

        // Counts
        // $skills = new Home();
        // $skill = $skills->Skills();

        $data = [
            // 'title_about' => 'About Me',
            'abouts' => $about,
            // 'counts' => $count,
            // 'skill' => $skill,
        ];
        return view('index', $data);
    }
}