<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>iPortfolio Bootstrap Template - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?= base_url() ?>/assets/img/favicon.png" rel="icon">
  <link href="<?= base_url() ?>/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?= base_url() ?>/assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?= base_url() ?>/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?= base_url() ?>/assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: iPortfolio
  * Template URL: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/
  * Updated: Mar 17 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Mobile nav toggle button ======= -->
  <i class="bi bi-list mobile-nav-toggle d-xl-none"></i>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="d-flex flex-column">

      <div class="nurahma">
        <img src="<?= base_url() ?>/assets/img/nurahma.jpg" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><a href="index.html">Alviani Nurahmadanti</a></h1>
        <div class="social-links mt-3 text-center">
          <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li><a href="#hero" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Home</span></a></li>
          <li><a href="#about" class="nav-link scrollto"><i class="bx bx-user"></i> <span>About</span></a></li>
          <li><a href="#resume" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Resume</span></a></li>
          <li><a href="#contact" class="nav-link scrollto"><i class="bx bx-envelope"></i> <span>Contact</span></a></li>
        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <img src="<?= base_url() ?>/assets/img/Alvi.jpg" class="img-fluid" alt="">
    <div class="hero-container" data-aos="fade-in">
      <h1>Alviani Nurahmadanti</h1>
      <p><span class="typed" data-typed-items="Mahasiswa, Teknik Informatika A,Semester 6, 2130511006"></span></p>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <?php foreach ($abouts as $about) : ?>
      <div class="container">

        <div class="section-title">
          <h2>About</h2>
          <p>Saya adalah seorang mahasiwa Teknik Informatika Semester 6 di Universitas Muhammadiyah Sukabumi </p>
        </div>

        <div class="row">
          <div class="col-lg-4" data-aos="fade-right">
            <img src="<?= base_url() ?>/assets/img/Alvi.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
            <h3><?= $about['name']; ?></h3>
            <p class="fst-italic">
              Berikut adalah beberapa biodata saya.
            </p>
            <div class="row">
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Birthday:</strong> <span><?= $about['Birthday']; ?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Email:</strong> <span><?= $about['Email']; ?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Phone:</strong> <span><?= $about['Phone']; ?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>City:</strong> <span><?= $about['City']; ?></span></li>
                </ul>
              </div>
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Age:</strong> <span>21</span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Instagram:</strong> <span>Alviani_nm</span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>NIM:</strong> <span>2130511006</span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Hoby:</strong> <span>Bernyanyi</span></li>
                </ul>
              </div>
            </div>
            <p>
              Saya adalah seorang mahasiswa teknik informatika semester 6 yang ingin mengengerjakan tugas UTS pemograman web framework
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->
    <?php endforeach ?>

    <!-- ======= Facts Section ======= -->
    <section id="facts" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Facts</h2>
          <p>Tugas UTS mata kuliah ini membuat CV WEB menggunakan codeigniter4</p>
        </div>
    </section><!-- End Facts Section -->

    <!-- ======= Skills Section ======= -->
    <section id="skills" class="skills section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Skills</h2>
          <p>Skill yang saya kuasai.</p>
        </div>

        <div class="row skills-content">

          <div class="col-lg-6" data-aos="fade-up">

            <div class="progress">
              <span class="skill">HTML <i class="val">30%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">CSS <i class="val">10%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">JavaScript <i class="val">15%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

          </div>

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">

            <div class="progress">
              <span class="skill">PHP <i class="val">35%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">WordPress/CMS <i class="val">25%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">Photoshop <i class="val">55%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section><!-- End Skills Section -->

    <!-- ======= Resume Section ======= -->
    <section id="resume" class="resume">
      <div class="container">

        <div class="section-title">
          <h2>Resume</h2>
          <p>Skill yang saya kuasai..</p>
        </div>

        <div class="row">
          <div class="col-lg-6" data-aos="fade-up">
            <h3 class="resume-title">Penejelasan skill</h3>
            <div class="resume-item pb-0">
              <h4>HTML</h4>
              <p><em>HTML (HyperText Markup Language) adalah bahasa standar untuk membuat dan menyusun halaman web. HTML menggunakan elemen-elemen yang disebut tag untuk menentukan struktur dan konten dari suatu halaman web, seperti teks, gambar, tautan, dan multimedia. Setiap elemen HTML ditulis dalam tanda kurung sudut yang memberikan instruksi kepada browser tentang bagaimana menampilkan konten. Dengan HTML, pengembang web dapat membuat halaman web yang terstruktur dan interaktif, serta dapat digabungkan dengan CSS (Cascading Style Sheets) dan JavaScript untuk mempercantik tampilan dan menambahkan fungsionalitas dinamis.</em></p>
            </div>

            <h3 class="resume-title">CSS</h3>
            <div class="resume-item">
              <h4>Penejelasan</h4>
              <p>CSS (Cascading Style Sheets) adalah bahasa yang digunakan untuk mendesain dan mengatur tampilan halaman web yang dibuat dengan HTML. Dengan CSS, pengembang web dapat mengontrol layout, warna, font, dan gaya visual lainnya dari elemen-elemen HTML, sehingga memisahkan konten dari presentasi. CSS memungkinkan penyesuaian desain yang konsisten di seluruh situs web dengan mendefinisikan aturan gaya yang dapat diterapkan pada beberapa elemen sekaligus. Selain itu, CSS mendukung berbagai perangkat dan ukuran layar, memungkinkan desain responsif yang menyesuaikan dengan berbagai resolusi dan orientasi layar. Hal ini membuat CSS menjadi alat yang esensial untuk menciptakan pengalaman pengguna yang menarik dan profesional di web.</p>
            </div>
            <div class="resume-item">
              <h4>JavaScript</h4>
              <p>JavaScript adalah bahasa pemrograman yang digunakan untuk menambahkan interaktivitas dan fungsionalitas dinamis pada halaman web. Berbeda dengan HTML dan CSS yang mengatur struktur dan tampilan, JavaScript memungkinkan pengembang untuk membuat elemen web yang responsif terhadap tindakan pengguna, seperti klik, input data, dan gerakan mouse. JavaScript dapat digunakan untuk validasi formulir, manipulasi DOM (Document Object Model), animasi, pengambilan data dari server (melalui AJAX), dan banyak lagi. Sebagai bahasa yang berjalan di sisi klien (browser), JavaScript memainkan peran penting dalam pengembangan web modern, memungkinkan pengalaman pengguna yang lebih kaya dan interaktif.</p>
            </div>
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <h3 class="resume-title">PHP</h3>
            <div class="resume-item">
                <li>PHP (Hypertext Preprocessor) adalah bahasa skrip server-side yang dirancang khusus untuk pengembangan web. PHP digunakan untuk membuat halaman web dinamis yang dapat berinteraksi dengan basis data dan menghasilkan konten yang berbeda berdasarkan input pengguna atau kondisi tertentu. Kode PHP dieksekusi di server dan hasilnya dikirimkan ke browser dalam bentuk HTML. Dengan kemampuan untuk berintegrasi dengan berbagai sistem basis data seperti MySQL, PostgreSQL, dan Oracle, PHP memungkinkan pengembang untuk membangun aplikasi web yang kompleks, seperti sistem manajemen konten, e-commerce, dan forum. Karena kemudahan penggunaannya dan dukungan luas dari komunitas, PHP menjadi salah satu bahasa pemrograman yang populer untuk pengembangan web.</li>
              </ul>
            </div>
            <div class="resume-item">
              <h4>CMS</h4>
              <ul>
                <li>CMS (Content Management System) adalah perangkat lunak yang memungkinkan pengguna untuk membuat, mengelola, dan memodifikasi konten digital di situs web tanpa memerlukan pengetahuan teknis yang mendalam tentang pemrograman web. Dengan antarmuka pengguna yang ramah dan alat pengelolaan konten yang intuitif, CMS memungkinkan pengguna untuk dengan mudah menambahkan, mengedit, dan menghapus teks, gambar, video, dan jenis konten lainnya. CMS populer seperti WordPress, Joomla, dan Drupal menyediakan berbagai tema dan plugin yang dapat disesuaikan untuk memenuhi kebutuhan spesifik situs web. Fitur-fitur CMS sering kali mencakup manajemen pengguna, penerbitan konten terjadwal, dan integrasi dengan media sosial, yang semuanya membantu dalam mengoptimalkan pengalaman pengguna dan meningkatkan efisiensi dalam pengelolaan situs web.</li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Resume Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Penutup</h2>
          <p> Sekian pengerjaan UTS pemograman WEb saya mohon maaf bila ada kesalahan.</p>
        </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Contact</h2>
        </div>

        <div class="row" data-aos="fade-in">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p>Takokak Cianjur</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>ALviani@gmail.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p>085687764456</p>
              </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>iPortfolio</span></strong>
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?= base_url() ?>/assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="<?= base_url() ?>/assets/vendor/aos/aos.js"></script>
  <script src="<?= base_url() ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url() ?>/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?= base_url() ?>/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?= base_url() ?>/assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?= base_url() ?>/assets/vendor/typed.js/typed.umd.js"></script>
  <script src="<?= base_url() ?>/assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="<?= base_url() ?>/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?= base_url() ?>/assets/js/main.js"></script>

</body>

</html>